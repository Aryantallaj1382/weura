<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ManhwaLike extends Model
{
    protected $fillable = [
        'user_id',
        'manhwa_id',
        'is_delete',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function manhwa()
    {
        return $this->belongsTo(Manhwa::class);
    }
}
