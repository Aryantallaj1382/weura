<?php $__env->startSection('content'); ?>
    <div class="p-6 space-y-6">
        <div class="flex justify-between items-center">
            <h1 class="text-xl font-bold text-white">📂 مدیریت دسته‌بندی‌ها</h1>
            <a href="<?php echo e(route('admin.blog_categories.create')); ?>" class="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg">➕ افزودن</a>
        </div>

        <?php if(session('success')): ?>
            <p class="bg-green-500 text-white p-2 rounded"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <table class="min-w-full border border-slate-600 rounded-lg overflow-hidden">
            <thead>
            <tr class="bg-slate-800 text-white">
                <th scope="col" class="px-4 py-2 text-center">#</th>
                <th scope="col" class="px-4 py-2 text-center">نام دسته‌بندی</th>
                <th scope="col" class="px-4 py-2 text-center">عملیات</th>
            </tr>
            </thead>
            <tbody class="divide-y divide-slate-700 bg-slate-900">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-slate-700 transition">
                    <td class="px-4 py-2 text-center"><?php echo e($categories->firstItem() + $index); ?></td>
                    <td class="px-4 py-2 text-center"><?php echo e($category->name); ?></td>
                    <td class="px-4 py-2 flex justify-center gap-2">
                        <a href="<?php echo e(route('admin.blog_categories.edit', $category->id)); ?>" class="px-3 py-1 bg-yellow-500 rounded hover:bg-yellow-600">ویرایش</a>
                        <form action="<?php echo e(route('admin.blog_categories.destroy', $category->id)); ?>" method="POST" onsubmit="return confirm('حذف شود؟')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="px-3 py-1 bg-red-500 rounded hover:bg-red-600">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($categories->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views/admin/BlogCategories/index.blade.php ENDPATH**/ ?>