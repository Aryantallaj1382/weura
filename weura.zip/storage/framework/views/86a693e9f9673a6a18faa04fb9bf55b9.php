<?php $__env->startSection('content'); ?>
    <div class="p-6 space-y-6">
        
        <div class="flex items-center justify-between px-6 py-4 border-b border-slate-700 bg-slate-900 rounded-t-lg">
            <h1 class="text-lg font-bold text-white">
                <span class="text-indigo-400"><?php echo e($manhwa->title); ?></span>
            </h1>
            <div class="flex items-center gap-2">
                
                <form action="<?php echo e(route('admin.manhwa.destroy', $manhwa->id)); ?>" method="POST" class="inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                            class="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white text-sm font-medium rounded-2xl shadow-md transition transform hover:scale-105">
                        حذف
                    </button>
                </form>

                
                <a href="<?php echo e(route('admin.manhwa.edit', $manhwa->id)); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white text-sm font-medium rounded-2xl shadow-md transition transform hover:scale-105">
                    ویرایش
                </a>

                
                <a href="<?php echo e(route('admin.chapters.create', $manhwa->id)); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-white text-sm font-medium rounded-2xl shadow-md transition transform hover:scale-105">
                    چپتر جدید
                </a>

                
                <a href="<?php echo e(route('admin.manhwa.index')); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white text-sm font-medium rounded-2xl shadow-md transition transform hover:scale-105">
                    بازگشت
                </a>
            </div>
        </div>

        <div class="flex flex-col lg:flex-row gap-6 bg-white dark:bg-slate-800 rounded-b-lg shadow p-6">
            <!-- تصویر -->
            <div class="w-full lg:w-1/3 flex justify-center items-center bg-gray-100 rounded-lg overflow-hidden">
                <img src="<?php echo e(asset($manhwa->cover_image)); ?>"
                     alt="<?php echo e($manhwa->title); ?>"
                     class="max-w-full max-h-full object-contain">
            </div>

            <!-- توضیحات -->
            <div class="flex-1 space-y-4">
                <h1 class="text-2xl font-bold text-slate-800 dark:text-slate-100"><?php echo e($manhwa->title); ?></h1>
                <p class="text-slate-600 dark:text-slate-300 line-clamp-5"><?php echo e($manhwa->summary); ?></p>
                <p class="text-sm text-slate-500 dark:text-slate-400">
                    نویسنده: <?php echo e($manhwa->author->name ?? '-'); ?> | هنرمند: <?php echo e($manhwa->artist->name ?? '-'); ?>

                </p>
                <p class="text-sm text-slate-500 dark:text-slate-400">
                    تعداد چپترها: <?php echo e($manhwa->chapters->count()); ?>

                </p>
            </div>
            <p class="text-sm text-slate-500 dark:text-slate-400">
                دسته‌بندی‌ها:
                <?php if($manhwa->categories->count()): ?>
                    <?php $__currentLoopData = $manhwa->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="inline-block bg-indigo-500 text-white px-2 py-1 rounded-full text-xs mr-1">
                    <?php echo e($category->name); ?>

                </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <span class="text-slate-400">ندارد</span>
                <?php endif; ?>
            </p>
        </div>



        
        <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-4">
            <h2 class="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-4">📖 لیست چپترها</h2>
            <?php if($manhwa->chapters->count()): ?>
                <table class="w-full text-sm text-left text-slate-700 dark:text-slate-300">
                    <thead class="bg-slate-900">
                    <tr>
                        <th class="px-4 py-2 text-white">#</th>
                        <th class="px-4 py-2 text-white">عنوان چپتر</th>
                        <th class="px-4 py-2 text-white">شماره چپتر</th>
                        <th class="px-4 py-2 text-white">وضعیت پرداخت</th>
                    </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-700">
                    <?php $__currentLoopData = $manhwa->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr onclick="window.location='<?php echo e(route('admin.chapter.show', $chapter->id)); ?>'" class="hover:bg-slate-700 transition cursor-pointer">
                            <td class="px-4 py-2 text-slate-200"><?php echo e($index + 1); ?></td>
                            <td class="px-4 py-2 text-slate-200"><?php echo e($chapter->title); ?></td>
                            <td class="px-4 py-2 text-slate-200"><?php echo e($chapter->chapter_number); ?></td>
                            <td class="px-4 py-2 text-slate-200">
                                <?php echo e($chapter->is_paid ? 'پولی' : 'رایگان'); ?>

                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-slate-400 text-center py-4">چپتری موجود نیست.</p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views\admin\manhwas\show.blade.php ENDPATH**/ ?>