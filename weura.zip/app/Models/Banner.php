<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    protected $table = 'banners';
    public  $guarded = [];
    public function manhuas()
    {
        return $this->belongsTo(Manhwa::class, 'manhwa_id');
    }}
