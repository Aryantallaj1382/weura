<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto p-6 space-y-6 bg-slate-800 rounded-2xl shadow">
        <h1 class="text-2xl font-bold text-white text-center">➕ افزودن کتاب جدید</h1>

        
        <?php if(session('success')): ?>
            <p class="bg-green-500 text-white p-2 rounded text-center"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        
        <?php if($errors->any()): ?>
            <div class="bg-red-500 text-white p-3 rounded mb-4">
                <ul class="list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.manhwa.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div>
                    <label class="block mb-1 text-slate-200 font-medium">عنوان</label>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>"
                           class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>

                
                <div>
                    <label class="block mb-1 text-slate-200 font-medium">وضعیت</label>
                    <select name="status"
                            class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">انتخاب وضعیت</option>
                        <option value="ongoing" <?php echo e(old('status') === 'ongoing' ? 'selected' : ''); ?>>منتشر شده</option>
                        <option value="ongoing" <?php echo e(old('status') === 'ongoing' ? 'selected' : ''); ?>>پیش‌نویس</option>
                    </select>
                </div>

                
                <div class="md:col-span-2">
                    <label class="block mb-1 text-slate-200 font-medium">خلاصه</label>
                    <textarea name="summary" rows="3"
                              class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"><?php echo e(old('summary')); ?></textarea>
                </div>

                
                <div>
                    <label class="block mb-1 text-slate-200 font-medium">نویسنده</label>
                    <select name="author_id"
                            class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">انتخاب نویسنده</option>
                        <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('author_id') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>



                
                <div>
                    <label class="block mb-1 text-slate-200 font-medium">هنرمند</label>
                    <select name="artist_id"
                            class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">انتخاب هنرمند</option>
                        <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('artist_id') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="flex-1">
                    <label class="block mb-1 text-slate-200 font-medium">دسته‌بندی‌ها</label>
                    <select id="categories" name="categories[]" multiple
                            class="w-full rounded-lg border border-slate-600 bg-slate-900 text-white">
                        <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e(collect(old('categories'))->contains($category->id) ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p class="text-xs text-slate-400 mt-1">می‌توانید چند دسته‌بندی انتخاب کنید یا جستجو کنید.</p>
                </div>

                
                <?php $__env->startPush('styles'); ?>
                    <link href="https://cdn.jsdelivr.net/npm/tom-select/dist/css/tom-select.css" rel="stylesheet">
                <?php $__env->stopPush(); ?>

                <?php $__env->startPush('scripts'); ?>
                    <script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>
                    <script>
                        document.addEventListener("DOMContentLoaded", function () {
                            new TomSelect("#categories", {
                                plugins: ['remove_button'],
                                placeholder: "دسته‌بندی‌ها را انتخاب کنید...",
                                persist: false,
                                create: false,
                                sortField: {field: "text", direction: "asc"}
                            });
                        });
                    </script>
                <?php $__env->stopPush(); ?>

                
                <div class="md:col-span-2">
                    <label class="block mb-1 text-slate-200 font-medium">کاور</label>
                    <input type="file" name="cover_image"
                           class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>
            </div>

            
            <div class="text-center">
                <button type="submit"
                        class="px-6 py-2 mt-4 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold rounded-lg shadow transition">
                    ذخیره کتاب
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views/admin/manhwas/create.blade.php ENDPATH**/ ?>