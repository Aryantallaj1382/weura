<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-slate-50 dark:bg-slate-900 flex items-center justify-center min-h-screen px-4">
<?php echo e($slot); ?>

</body>
</html>
<?php /**PATH E:\weura\resources\views/layouts/guest.blade.php ENDPATH**/ ?>