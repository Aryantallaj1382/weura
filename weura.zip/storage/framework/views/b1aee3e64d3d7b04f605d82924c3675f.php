<?php $__env->startSection('content'); ?>
    <div class="max-w-lg mx-auto p-6 bg-slate-800 rounded-lg">
        <h1 class="text-xl text-white mb-4">✏️ ویرایش دسته‌بندی</h1>

        <form action="<?php echo e(route('admin.blog_categories.update', $BlogCategory->id)); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>
                <label class="text-white">نام دسته‌بندی</label>
                <input type="text" name="name" value="<?php echo e(old('name', $BlogCategory->name)); ?>" class="w-full p-2 rounded bg-slate-900 text-white border border-slate-600">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-400"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button class="px-4 py-2 bg-indigo-500 rounded">ذخیره تغییرات</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views/admin/BlogCategories/edit.blade.php ENDPATH**/ ?>