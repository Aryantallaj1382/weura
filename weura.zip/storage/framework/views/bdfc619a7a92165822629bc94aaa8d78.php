<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto p-6 space-y-6 bg-slate-800 rounded-2xl shadow">
        <h1 class="text-2xl font-bold text-white text-center">ویرایش کتاب: <?php echo e($manhwa->title); ?></h1>

        <?php if(session('success')): ?>
            <p class="bg-green-500 text-white p-2 rounded text-center"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.manhwa.update', $manhwa->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block mb-1 text-slate-200 font-medium">عنوان</label>
                    <input type="text" name="title" value="<?php echo e(old('title', $manhwa->title)); ?>"
                           class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>

                <div>
                    <label class="block mb-1 text-slate-200 font-medium">وضعیت</label>
                    <select name="status"
                            class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="ongoing" <?php echo e($manhwa->status === 'ongoing' ? 'selected' : ''); ?>>منتشر شده</option>
                        <option value="ongoing" <?php echo e($manhwa->status === 'ongoing' ? 'selected' : ''); ?>>پیش‌نویس</option>
                    </select>
                </div>

                <div class="md:col-span-2">
                    <label class="block mb-1 text-slate-200 font-medium">خلاصه</label>
                    <textarea name="summary" rows="3"
                              class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"><?php echo e(old('summary', $manhwa->summary)); ?></textarea>
                </div>

                <div>
                    <label class="block mb-1 text-slate-200 font-medium">نویسنده</label>
                    <select name="author_id"
                            class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">انتخاب نویسنده</option>
                        <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e($manhwa->author_id == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block mb-1 text-slate-200 font-medium">هنرمند</label>
                    <select name="artist_id"
                            class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">انتخاب هنرمند</option>
                        <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e($manhwa->artist_id == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="md:col-span-2">
                    <label class="block mb-1 text-slate-200 font-medium">دسته‌بندی‌ها</label>
                    <select id="categories" name="categories[]" multiple
                            class="w-full rounded-lg border border-slate-600 bg-slate-900 text-white">
                        <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"
                                <?php echo e($manhwa->categories->contains($category->id) ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <p class="text-xs text-slate-400 mt-1">می‌توانید چند دسته‌بندی انتخاب کنید، انتخاب‌ها به بالا منتقل می‌شوند.</p>
                </div>

                <?php $__env->startPush('styles'); ?>
                    <link href="https://cdn.jsdelivr.net/npm/tom-select/dist/css/tom-select.css" rel="stylesheet">
                    <style>
                        /* هماهنگ‌سازی با تم تیره */
                        .ts-control {
                            background-color: #0f172a !important; /* slate-900 */
                            border-color: #475569 !important; /* slate-600 */
                            color: white !important;
                        }
                        .ts-dropdown {
                            background-color: #1e293b !important; /* slate-800 */
                            color: white !important;
                        }
                        .ts-control .item {
                            background-color: #4f46e5; /* indigo-600 */
                            border-radius: 0.5rem;
                            padding: 0.25rem 0.5rem;
                            margin: 0.15rem;
                        }
                    </style>
                <?php $__env->stopPush(); ?>

                <?php $__env->startPush('scripts'); ?>
                    <script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>
                    <script>
                        document.addEventListener("DOMContentLoaded", function () {
                            new TomSelect("#categories", {
                                plugins: ['remove_button'],
                                placeholder: "دسته‌بندی‌ها را انتخاب کنید...",
                                persist: false,
                                create: false,
                                sortField: {field: "text", direction: "asc"},
                                render: {
                                    option: function(data, escape) {
                                        return `<div>${escape(data.text)}</div>`;
                                    },
                                    item: function(data, escape) {
                                        return `<div class="bg-indigo-600 text-white rounded-lg px-2 py-1">${escape(data.text)}</div>`;
                                    }
                                }
                            });
                        });
                    </script>
                <?php $__env->stopPush(); ?>


                <div class="md:col-span-2">
                    <label class="block mb-1 text-slate-200 font-medium">کاور</label>
                    <input type="file" name="cover_image"
                           class="w-full p-2 rounded-lg border border-slate-600 bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <?php if($manhwa->cover_image): ?>
                        <img src="<?php echo e(asset($manhwa->cover_image)); ?>" alt="کاور" class="w-32 mt-2 rounded-lg border border-slate-600">
                    <?php endif; ?>
                </div>
            </div>

            <div class="text-center">
                <button type="submit"
                        class="px-6 py-2 mt-4 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold rounded-lg shadow transition">ذخیره تغییرات</button>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views\admin\manhwas\edit.blade.php ENDPATH**/ ?>