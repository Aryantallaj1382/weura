<?php $__env->startSection('content'); ?>
    <div class="p-6">

        <div class="flex items-center justify-between mb-6">
            <h1 class="text-2xl font-bold">📚 تمام مانهواها</h1>

            <a href="<?php echo e(route('admin.manhwa.create')); ?>"
               class="inline-flex items-center gap-2 px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white text-sm font-medium rounded-lg shadow-sm transition transform hover:scale-105">
                ایجاد کتاب جدید
            </a>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2  lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $manhwas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manhwa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <a href="<?php echo e(route('admin.manhwa.show', $manhwa->id)); ?>" class="block bg-white hover:bg-gray-700 dark:bg-slate-800 rounded-lg shadow hover:shadow-lg transition overflow-hidden">
                    <img src="<?php echo e(asset($manhwa->cover_image)); ?>" alt="<?php echo e($manhwa->title); ?>" class="w-full h-48 object-cover">
                    <div class="p-4">
                        <h2 class="text-lg font-semibold text-slate-800 dark:text-slate-100"><?php echo e($manhwa->title); ?></h2>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-6">
            <?php echo e($manhwas->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views/admin/manhwas/index.blade.php ENDPATH**/ ?>