<?php $__env->startSection('content'); ?>
    <div class="p-6 bg-slate-900 rounded-lg max-w-3xl mx-auto shadow-lg">
        
        <h1 class="text-3xl font-extrabold text-white mb-4 text-center"><?php echo e($blog->title); ?></h1>

        
        <div class="flex flex-col sm:flex-row justify-between mb-4 text-slate-300 text-sm sm:text-base gap-2">
            <p><strong>نویسنده:</strong> <?php echo e($blog->author); ?></p>
            <p><strong>دسته‌بندی:</strong> <?php echo e($blog->category->name); ?></p>
        </div>

        
        <?php if($blog->image): ?>
            <img src="<?php echo e(asset($blog->image)); ?>" class="w-full rounded-lg shadow-md mb-6 object-cover max-h-96" alt="تصویر بلاگ">
        <?php endif; ?>

        
        <div class="text-white leading-relaxed whitespace-pre-wrap mb-6 border-l-4 border-indigo-500 pl-4">
            <?php echo e($blog->content); ?>

        </div>

        
        <div class="text-center">
            <a href="<?php echo e(route('admin.blog.index')); ?>" class="inline-block px-6 py-3 bg-indigo-500 text-white font-semibold rounded-lg hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-400 transition">
                بازگشت به لیست بلاگ‌ها
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views\admin\Blog\show.blade.php ENDPATH**/ ?>