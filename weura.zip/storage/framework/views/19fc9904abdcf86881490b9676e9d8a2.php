<?php $__env->startSection('content'); ?>
    <div class="p-6 bg-slate-900 rounded-lg max-w-3xl mx-auto shadow-lg">
        <h1 class="text-2xl font-bold text-white mb-6 text-center">ایجاد بلاگ جدید</h1>

        <form action="<?php echo e(route('admin.blog.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-5">
            <?php echo csrf_field(); ?>

            
            <div>
                <label class="text-white block mb-2 font-medium">دسته‌بندی</label>
                <select name="category_id" class="w-full p-3 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div>
                <label class="text-white block mb-2 font-medium">عنوان</label>
                <input type="text" name="title" class="w-full p-3 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition" placeholder="عنوان بلاگ" required>
            </div>

            
            <div>
                <label class="text-white block mb-2 font-medium">نویسنده</label>
                <input type="text" name="author" class="w-full p-3 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition" placeholder="نام نویسنده" required>
            </div>

            
            <div>
                <label class="text-white block mb-2 font-medium">محتوا</label>
                <textarea name="content" class="w-full p-3 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition h-48" placeholder="متن بلاگ..." required></textarea>
            </div>

            
            <div>
                <label class="text-white block mb-2 font-medium">تصویر</label>
                <input type="file" name="image" class="w-full text-white rounded-lg bg-slate-800 border border-slate-700 p-2 file:bg-indigo-500 file:text-white file:rounded-lg file:px-3 file:py-1 hover:file:bg-indigo-600 transition">
            </div>

            
            <div class="text-center">
                <button type="submit" class="px-6 py-3 bg-indigo-500 text-white font-semibold rounded-lg hover:bg-indigo-600 focus:ring-2 focus:ring-indigo-400 transition">
                    ایجاد بلاگ
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views\admin\Blog\create.blade.php ENDPATH**/ ?>