<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next)
    {
        // اولویت: header -> query -> default
        $locale = $request->header('Accept-Language') ?? $request->query('lang');

        // زبان‌های پشتیبانی‌شده
        $supportedLocales = ['fa', 'en', 'ar'];

        // بررسی و تنظیم
        if (in_array($locale, $supportedLocales)) {
            App::setLocale($locale);
        } else {
            App::setLocale('fa'); // پیش‌فرض فارسی
        }

        return $next($request);
    }

}
