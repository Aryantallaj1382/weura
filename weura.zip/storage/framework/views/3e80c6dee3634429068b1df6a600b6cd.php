<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h1 class="text-2xl font-bold text-white mb-6">👥 لیست کاربران</h1>

        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-slate-700 dark:text-slate-300">
                <thead class="bg-slate-900">
                <tr>
                    <th class="w-1/12 px-4 py-3 text-left text-sm font-semibold text-white">#</th>
                    <th class="w-3/12 px-4 py-3 text-left text-sm font-semibold text-white">نام</th>
                    <th class="w-4/12 px-4 py-3 text-left text-sm font-semibold text-white">ایمیل</th>
                    <th class="w-4/12 px-4 py-3 text-left text-sm font-semibold text-white">تاریخ ثبت</th>
                    <th class="w-4/12 px-4 py-3 text-left text-sm font-semibold text-white">نمایش</th>
                </tr>
                </thead>
                <tbody class="divide-y divide-slate-700">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-slate-700 transition">
                        <td class="px-4 py-3 text-sm text-slate-200"><?php echo e($index + 1); ?></td>
                        <td class="px-4 py-3 text-sm text-slate-200 break-words"><?php echo e($user->name); ?></td>
                        <td class="px-4 py-3 text-sm text-slate-200 break-words"><?php echo e($user->email); ?></td>
                        <td class="px-4 py-3 text-sm text-slate-400 whitespace-nowrap">
                            <?php echo e(\Morilog\Jalali\Jalalian::fromDateTime($user->created_at)->format('Y/m/d')); ?>

                        </td>
                        <td class="px-4 py-3 text-sm text-slate-200 break-words">
                            <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="text-indigo-400 hover:underline">
                               جزئیات
                            </a>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


        </div>
        <div class="mt-6">
            <?php echo e($users->links()); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views\admin\users\index.blade.php ENDPATH**/ ?>