<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h1 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-6">📩 لیست تیکت‌ها</h1>

        <div class="overflow-x-auto bg-white dark:bg-slate-800 rounded-xl shadow-lg">
            <div class="mb-4">
                <form method="GET" action="<?php echo e(route('admin.tickets.index')); ?>">
                    <select name="status"
                            onchange="this.form.submit()"
                            class="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-800 dark:text-white">
                        <option value="">همه وضعیت‌ها</option>
                        <option value="open" <?php echo e(request('status') == 'open' ? 'selected' : ''); ?>>باز</option>
                        <option value="closed" <?php echo e(request('status') == 'closed' ? 'selected' : ''); ?>>بسته</option>
                    </select>
                </form>
            </div>


            <table class="w-full text-sm text-left text-slate-700 dark:text-slate-300">
                <thead class="bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
                <tr>
                    <th class="px-4 py-3">کاربر</th>
                    <th class="px-4 py-3">موضوع</th>
                    <th class="px-4 py-3">وضعیت</th>
                    <th class="px-4 py-3">عملیات</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b border-slate-200 dark:border-slate-700  dark:hover:bg-slate-600 transition">
                        <td class="px-4 py-3 font-medium text-white"><?php echo e($ticket->user->name); ?></td>
                        <td class="px-4 py-3 font-medium text-white"><?php echo e($ticket->issue_type); ?></td>
                        <td class="px-4 py-3 font-medium text-white">
                            <?php if($ticket->status === 'open'): ?>
                                <span class="px-2 py-1 text-xs font-semibold text-green-800 bg-green-100 dark:bg-green-800 dark:text-green-100 rounded-lg">باز</span>
                            <?php else: ?>
                                <span class="px-2 py-1 text-xs font-semibold text-red-800 bg-red-100 dark:bg-red-800 dark:text-red-100 rounded-lg">بسته</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3">
                            <a href="<?php echo e(route('admin.tickets.show', $ticket->id)); ?>"
                               class="inline-flex items-center px-3 py-1.5 text-sm font-medium text-white bg-indigo-500 hover:bg-indigo-600 rounded-lg shadow transition">
                                مشاهده
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <?php echo e($tickets->appends(request()->query())->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views\admin\tickets\index.blade.php ENDPATH**/ ?>