<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\Chapter;
use App\Models\Manhwa;
use App\Models\SystemSetting;
use App\Models\Ticket;
use App\Models\Transaction;
use App\Models\User;
use App\Models\UserActivity;
use App\Models\Wallet;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Morilog\Jalali\Jalalian;

class DashboardController extends Controller
{
    public function main()
    {

        return view('admin.main');

    }

    public function aryan()
    {
        $file1 = SystemSetting::where('name','file')->first();
        $value = url('public/'.$file1->value);
        return view('admin.aryan', compact('value'));

    }
    public function soft()
    {

        return view('admin.soft');

    }
    public function save(Request $request)
    {

        $request->validate([
            'image' => 'nullable',
        ]);

        $file1 = SystemSetting::where('name','file')->first();
        $image = null;
        if ($request->hasFile('image')) {
            $destinationPath = public_path('image');
            if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0755, true);
            }
            $file = $request->file('image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move($destinationPath, $filename);
            $image = 'image/' . $filename;
        }
        $file1->update([
            'value' => $image,
        ]);



        return redirect()->route('aryan')->with('success', 'دستت درد نکنه.');

    }
    public function index()
    {
        // تعداد کاربران
        $userCount = User::count();

        // تعداد مانهوآها
        $manhwaCount = Manhwa::count();
        $ChapterCount =  Chapter::count();
        $BlogCount = Blog::count();
        $viewCount = Manhwa::sum('view');

        // مجموع موجودی کیف پول
        $totalBalance = Wallet::sum('balance');

        // تعداد تیکت‌های باز
        $ticket = Ticket::where('status', 'open')->count();

        $dates = collect();
        $userCounts = collect();

        $ac = UserActivity::latest()->take(5)->get();
        // حلقه ۳۰ روز اخیر
        for ($i = 15; $i >= 0; $i--) {
            $date = Carbon::now()->subDays($i);
            $dates->push(Jalalian::fromCarbon($date)->format('d / m')); // روز / ماه شمسی

            $count = User::whereDate('created_at', $date)->count();
            $userCounts->push((int) $count); // عدد صحیح
        }

        // آماده‌سازی userStats برای ویو
        $userStats = [
            'dates' => $dates,
            'counts' => $userCounts,
        ];
        $transaction = Transaction::where('operation_type', 'deposit')->where('status', 'pending')->get();

        // ارسال داده‌ها به ویو
        return view('admin.dashboard', compact('userCount', 'manhwaCount', 'totalBalance', 'ticket', 'userStats' , 'transaction' ,
        'ChapterCount', 'BlogCount', 'viewCount' , 'ac'));
    }

}
