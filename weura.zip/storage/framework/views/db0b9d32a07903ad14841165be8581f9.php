<?php $__env->startSection('content'); ?>
    <div class="p-6 bg-slate-900 rounded-lg max-w-3xl mx-auto shadow-lg">
        <h1 class="text-2xl font-bold text-white mb-6 text-center">ویرایش بلاگ</h1>

        <form action="<?php echo e(route('admin.blog.update', $blog->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            
            <div>
                <label class="text-white block mb-2 font-medium">دسته‌بندی</label>
                <select name="category_id" class="w-full p-3 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($blog->category_id == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div>
                <label class="text-white block mb-2 font-medium">عنوان</label>
                <input type="text" name="title" class="w-full p-3 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition" value="<?php echo e($blog->title); ?>" required>
            </div>

            
            <div>
                <label class="text-white block mb-2 font-medium">نویسنده</label>
                <input type="text" name="author" class="w-full p-3 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition" value="<?php echo e($blog->author); ?>" required>
            </div>

            
            <div>
                <label class="text-white block mb-2 font-medium">محتوا</label>
                <textarea name="content" class="w-full p-3 rounded-lg bg-slate-800 text-white border border-slate-700 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition h-48" required><?php echo e($blog->content); ?></textarea>
            </div>

            
            <div>
                <label class="text-white block mb-2 font-medium">تصویر</label>
                <input type="file" name="image" class="w-full text-white rounded-lg bg-slate-800 border border-slate-700 p-2 file:bg-yellow-500 file:text-white file:rounded-lg file:px-3 file:py-1 hover:file:bg-yellow-600 transition">

                <?php if($blog->image): ?>
                    <img src="<?php echo e(asset('storage/'.$blog->image)); ?>" class="w-32 mt-3 rounded shadow-md" alt="تصویر بلاگ">
                <?php endif; ?>
            </div>

            
            <div class="text-center">
                <button type="submit" class="px-6 py-3 bg-yellow-500 text-white font-semibold rounded-lg hover:bg-yellow-600 focus:ring-2 focus:ring-yellow-400 transition">
                    ویرایش بلاگ
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views\admin\Blog\edit.blade.php ENDPATH**/ ?>