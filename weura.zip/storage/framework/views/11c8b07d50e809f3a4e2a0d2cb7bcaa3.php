<?php $__env->startSection('content'); ?>
    <div class="p-6 bg-slate-800 rounded-lg">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-xl font-bold text-white">مدیریت بلاگ‌ها</h1>
            <a href="<?php echo e(route('admin.blog.create')); ?>" class="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition">
                ایجاد بلاگ جدید
            </a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-slate-700 rounded-lg overflow-hidden relative group">
                    
                    <img src="<?php echo e(asset($blog->image)); ?>" alt="<?php echo e($blog->title); ?>" class="w-full h-48 object-cover">

                    
                    <div class="p-4">
                        <h2 class="text-white font-semibold text-lg"><?php echo e($blog->title); ?></h2>
                    </div>

                    
                    <div class="absolute top-2 right-2">
                        <div class="relative inline-block text-left">
                            <button class="text-white font-bold p-1 rounded hover:bg-slate-600 transition">•••</button>
                            <div class="hidden group-hover:block absolute right-0 mt-2 w-36 bg-slate-800 rounded shadow-lg z-10">
                                <a href="<?php echo e(route('admin.blog.show', $blog->id)); ?>" class="block px-4 py-2 text-sm text-white hover:bg-slate-600">نمایش</a>
                                <a href="<?php echo e(route('admin.blog.edit', $blog->id)); ?>" class="block px-4 py-2 text-sm text-white hover:bg-slate-600">ویرایش</a>
                                <form action="<?php echo e(route('admin.blog.destroy', $blog->id)); ?>" method="POST" onsubmit="return confirm('آیا مطمئن هستید؟');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="w-full text-left px-4 py-2 text-sm text-white hover:bg-slate-600">حذف</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="mt-6">
            <?php echo e($blogs->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views\admin\Blog\index.blade.php ENDPATH**/ ?>