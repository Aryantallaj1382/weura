<?php $__env->startSection('content'); ?>
    <div class="p-6 space-y-6">
        <div class="flex items-center px-6 py-4 border-b border-slate-700 bg-slate-900 rounded-t-lg">
            <h1 class="text-lg font-bold text-white mr-auto">
            </h1>

            <div class="flex items-center gap-2">
                
                <a href="<?php echo e(route('admin.manhwa.show', $chapter->manhua->id)); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg shadow-sm transition transform hover:scale-105">
                    بازگشت
                </a>

                
                <a href="<?php echo e(route('admin.chapters.edit', $chapter->id)); ?>"
                   class="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg shadow-sm transition transform hover:scale-105">
                    ویرایش
                </a>

                
                <form action="<?php echo e(route('admin.chapters.destroy', $chapter->id)); ?>" method="POST" class="inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                            class="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-lg shadow-sm transition transform hover:scale-105">
                        حذف
                    </button>
                </form>
            </div>
        </div>


        <div class="flex flex-col lg:flex-row gap-6 bg-white dark:bg-slate-800 rounded-lg shadow p-4">
            
            <div class="w-full lg:w-1/4 flex justify-center items-center bg-gray-100 rounded-lg overflow-hidden">
                <img src="<?php echo e(asset($chapter->manhua->cover_image)); ?>"
                     alt="<?php echo e($chapter->manhua->title); ?>"
                     class="max-w-full max-h-full object-contain">
            </div>

            
            <div class="flex-1 space-y-2">
                <h1 class="text-2xl font-bold text-slate-800 dark:text-slate-100"><?php echo e($chapter->title); ?></h1>
                <p class="text-slate-600 dark:text-slate-300">
                    شماره چپتر: <?php echo e($chapter->chapter_number); ?>

                </p>
                <p class="text-slate-600 dark:text-slate-300">
                    وضعیت پرداخت: <?php echo e($chapter->is_paid ? 'پرداخت شده' : 'رایگان'); ?>

                </p>
                <p class="text-slate-600 dark:text-slate-300">
                    مانهوا: <?php echo e($chapter->manhua->title); ?>

                </p>
                <?php if($chapter->description): ?>
                    <p class="text-slate-500 dark:text-slate-400 mt-2"><?php echo e($chapter->description); ?></p>
                <?php endif; ?>
            </div>
        </div>

        
        <?php if($chapter->image): ?>
            <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-4 flex justify-center">
                <img src="<?php echo e(asset($chapter->image)); ?>" alt="<?php echo e($chapter->title); ?>" class="max-w-full max-h-full object-contain">
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\weura\resources\views/admin/chapters/show.blade.php ENDPATH**/ ?>